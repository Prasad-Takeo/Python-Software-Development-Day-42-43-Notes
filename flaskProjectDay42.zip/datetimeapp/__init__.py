from flask import Flask

datetimeapp = Flask(__name__)

from datetimeapp import routes