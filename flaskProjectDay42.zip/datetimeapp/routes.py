from datetimeapp import datetimeapp
from datetime import datetime

@datetimeapp.route("/currentdatetime")
def currentdatetime():
    return f"The current datetime is {datetime.now()}"

@datetimeapp.route("/")
def index():
    return f"welcome to the datetime app"


"""
Food ordering application like swiggy or zomato

Ordering
delivering
feedback

horizontal scaling - cluster ( more in production ) docker/kubernetes

1 2 3 4 ( flask )
ordering delivery feedback

django 

vertical scaling
"""