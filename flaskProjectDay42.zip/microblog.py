from app import app

"""
creata a flask application and return current datetime
/currentdatetime
the current datetime is 2022-05-18 hh:mm:ss
"""