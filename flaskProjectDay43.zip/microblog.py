from app import app
print(app.config)